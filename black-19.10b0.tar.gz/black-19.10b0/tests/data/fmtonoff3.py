# fmt: off
x = [
    1, 2,
    3, 4,
]
# fmt: on

# fmt: off
x = [
    1, 2,
    3, 4,
]
# fmt: on

x = [
    1, 2, 3, 4
]

# output

# fmt: off
x = [
    1, 2,
    3, 4,
]
# fmt: on

# fmt: off
x = [
    1, 2,
    3, 4,
]
# fmt: on

x = [1, 2, 3, 4]
