#!/usr/bin/env python3.6

name = R"Łukasz"
F"hello {name}"
B"hello"

# output


#!/usr/bin/env python3.6

name = r"Łukasz"
f"hello {name}"
b"hello"
