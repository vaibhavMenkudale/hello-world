# pylint: disable=missing-docstring,redefined-builtin

from sys import exit

exit(0)
