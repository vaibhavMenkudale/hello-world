# pylint: disable=missing-docstring,import-outside-toplevel,redefined-builtin

def run():
    from sys import exit
    exit()
