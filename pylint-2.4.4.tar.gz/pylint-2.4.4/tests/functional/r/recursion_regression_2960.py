# pylint: disable=missing-docstring
from runpy import run_path

_STH = run_path('hello.py')
