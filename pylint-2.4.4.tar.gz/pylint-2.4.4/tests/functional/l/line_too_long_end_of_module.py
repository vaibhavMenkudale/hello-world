#pylint: disable=missing-docstring, line-too-long

# Hey this is a very long commented line just to trigger pylint's line-too-long message. It is just above a dummy function with a very long code line.
def dummy_function():
    print("What a beautiful dummy function with such a very long line inside that it should trigger pylint's line-too-long message ")

# Hey this is a very long commented line at the end of the module. It is just here to trigger pylint's line-too-long message.
